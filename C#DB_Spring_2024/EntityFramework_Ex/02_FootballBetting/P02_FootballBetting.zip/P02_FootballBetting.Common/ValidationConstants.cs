﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Common
{
    public static class ValidationConstants
    {
        public const int CountryNameMaxLength = 50;
        public const int TownNameMaxLength = 128;
    }
}
