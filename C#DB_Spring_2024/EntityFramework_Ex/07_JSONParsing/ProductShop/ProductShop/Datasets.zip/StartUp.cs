﻿using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            //using ProductShopContext context = new ProductShopContext();
            //string usersJson = File.ReadAllText("../../../Datasets/users.json");
            //ImportUsers(context, usersJson);
        }
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            List<User> users = JsonConvert.DeserializeObject<List<User>>(inputJson);
            context.Users.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users?.Count}";
        }
    }
}