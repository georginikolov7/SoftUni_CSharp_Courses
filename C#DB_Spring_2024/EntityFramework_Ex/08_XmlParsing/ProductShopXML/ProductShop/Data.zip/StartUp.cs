﻿using System.Globalization;
using System.Text;
using System.Xml.Serialization;
using System.Xml;
using ProductShop.Data;
using ProductShop.Models;
using ProductShop.DTOs.Import;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {

            using ProductShopContext context = new ProductShopContext();
            string usersXML = File.ReadAllText("../../../Datasets/users.xml");
            string productsXml = File.ReadAllText("../../../Datasets/products.xml");
            string catXML = File.ReadAllText("../../../Datasets/categories.xml");
            string catProductsXML = File.ReadAllText("../../../Datasets/categories-products.xml");

            //Console.WriteLine(ImportUsers(context, usersXML));
            //Console.WriteLine(ImportProducts(context, productsXml));
            //Console.WriteLine(ImportCategories(context, catXML));
            Console.WriteLine(ImportCategoryProducts(context,catProductsXML));
        }
        //Imports:
        //01:
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new(typeof(UserImportDto[]), new XmlRootAttribute("Users"));

            UserImportDto[] dtos;

            using (StringReader reader = new StringReader(inputXml))
            {
                dtos = serializer.Deserialize(reader) as UserImportDto[];
            }




            User[] users = dtos.Select(u => new User()
            {
                FirstName = u.FirstName,
                LastName = u.LastName,
                Age = u.Age,
            })
                .ToArray();


            context.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users.Length}";

        }
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new(typeof(ProductImportDto[]), new XmlRootAttribute("Products"));

            ProductImportDto[] dtos;

            using (StringReader reader = new StringReader(inputXml))
            {
                dtos = serializer.Deserialize(reader) as ProductImportDto[];
            }

            var validIds = context.Users.Select(u => u.Id).ToList();

            Product[] products = dtos.Select(p => new Product()
            {
                Name = p.Name,
                Price = p.Price,
                SellerId = p.SellerId,
                BuyerId = p.BuyerId,
            })
                //.Where(p => validIds.Contains((int)p.BuyerId) && validIds.Contains(p.SellerId))
                .ToArray();

            context.Products.AddRange(products);
            context.SaveChanges();
            return $"Successfully imported {products.Length}";
        }
        public static string ImportCategories(ProductShopContext context, string inputXml)
        {

            XmlSerializer serializer = new(typeof(CategoryImportDto[]), new XmlRootAttribute("Categories"));

            CategoryImportDto[] dtos;

            using (StringReader reader = new StringReader(inputXml))
            {
                dtos = serializer.Deserialize(reader) as CategoryImportDto[];
            }

            Category[] categories = dtos.Select(p => new Category()
            {
                Name = p.Name,
            })
                .Where(c => c.Name is not null)
                .ToArray();

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Length}";
        }
        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new(typeof(CategoryProductImportDto[]), new XmlRootAttribute("CategoryProducts"));

            CategoryProductImportDto[] dtos;

            using (StringReader reader = new StringReader(inputXml))
            {
                dtos = serializer.Deserialize(reader) as CategoryProductImportDto[];
            }


            var validCategoryIds = context.Categories.Select(c => c.Id).ToList();

            var validProductIds = context.Products.Select(p => p.Id).ToList();

            CategoryProduct[] categoriesProducts = dtos.Select(cp => new CategoryProduct()
            {
                CategoryId = cp.CategoryId,
                ProductId = cp.ProductId
            })
                .Where(cp => validCategoryIds.Contains(cp.CategoryId) && validProductIds.Contains(cp.ProductId))
                .ToArray();

            context.CategoryProducts.AddRange(categoriesProducts);
            context.SaveChanges();

            return $"Successfully imported {categoriesProducts.Length}";
        }



        //<Summary>: Method for serializing dtos to XML</Summary>
        private static string SerializeToXML<T>(T dto, string xmlRootAttribute, bool omitDeclarations = false)
        {
            XmlSerializer serializer = new(typeof(T), new XmlRootAttribute(xmlRootAttribute));

            StringBuilder sb = new();

            //Settings:
            XmlWriterSettings settings = new()
            {
                OmitXmlDeclaration = omitDeclarations,
                Encoding = new UTF8Encoding(false),
                Indent = true
            };

            using StringWriter stringWriter = new StringWriter(sb, CultureInfo.InvariantCulture);
            using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, settings))
            {
                XmlSerializerNamespaces namespaces = new();
                namespaces.Add(string.Empty, string.Empty);

                try
                {
                    serializer.Serialize(xmlWriter, dto, namespaces);
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
            return sb.ToString();

        }
    }
}