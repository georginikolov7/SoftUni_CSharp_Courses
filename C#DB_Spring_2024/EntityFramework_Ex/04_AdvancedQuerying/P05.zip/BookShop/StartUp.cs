﻿namespace BookShop
{
    using BookShop.Models;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            Console.WriteLine(GetBooksNotReleasedIn(db,2000));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            Enum.TryParse(command, true, out AgeRestriction ageRestriction);
            List<string> titles = context.Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .OrderBy(b => b.Title)
                .Select(b => b.Title)
                .ToList();

            return string.Join(Environment.NewLine, titles);
        }
        public static string GetGoldenBooks(BookShopContext context)
        {
            List<string> titles = context.Books
                .Where(b => b.EditionType == EditionType.Gold && b.Copies < 5_000)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToList();

            return String.Join(Environment.NewLine, titles);
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            var resultBooks = context.Books
                .Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .Select(b => new
                {
                    b.Title,
                    b.Price
                })
                .ToList();
            StringBuilder sb = new();
            foreach (var book in resultBooks)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:f2}");
            }
            return sb.ToString().Trim();
        }
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var resultBooks = context.Books
                .Where(book => book.ReleaseDate.Value.Year != year)
                .OrderBy(book => book.BookId)
                .Select(book => book.Title)
                .ToList();

            return String.Join(Environment.NewLine, resultBooks); 
        }
    }
}


