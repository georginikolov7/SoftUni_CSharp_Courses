﻿namespace BookShop
{
    using BookShop.Models;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            Console.WriteLine(GetBooksReleasedBefore(db, "12-04-1992"));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            Enum.TryParse(command, true, out AgeRestriction ageRestriction);
            List<string> titles = context.Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .OrderBy(b => b.Title)
                .Select(b => b.Title)
                .ToList();

            return string.Join(Environment.NewLine, titles);
        }
        public static string GetGoldenBooks(BookShopContext context)
        {
            List<string> titles = context.Books
                .Where(b => b.EditionType == EditionType.Gold && b.Copies < 5_000)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToList();

            return String.Join(Environment.NewLine, titles);
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            var resultBooks = context.Books
                .Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .Select(b => new
                {
                    b.Title,
                    b.Price
                })
                .ToList();
            StringBuilder sb = new();
            foreach (var book in resultBooks)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:f2}");
            }
            return sb.ToString().Trim();
        }
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var resultBooks = context.Books
                .Where(book => book.ReleaseDate.Value.Year != year)
                .OrderBy(book => book.BookId)
                .Select(book => book.Title)
                .ToList();

            return String.Join(Environment.NewLine, resultBooks);
        }
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            string[] categories = input
                .ToLower()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            var titles = context.BooksCategories
                .Where(bc => categories.Contains(bc.Category.Name.ToLower()))
                .Select(b => b.Book.Title)
                .OrderBy(b => b)
                .ToList();
            return String.Join(Environment.NewLine, titles);
        }
        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            var resultDate = DateTime.ParseExact(date, "dd-MM-yyyy",CultureInfo.InvariantCulture);
            var resultBooks = context.Books
                .Where(b => b.ReleaseDate < resultDate)
                .OrderByDescending(b => b.ReleaseDate)
                .Select(b => new
                {
                    b.Title,
                    b.EditionType,
                    b.Price
                })
                .ToList();
            StringBuilder sb = new();
            foreach (var book in resultBooks)
            {
                sb.AppendLine($"{book.Title} - {book.EditionType} - ${book.Price:f2}");
            }
            return sb.ToString().Trim();
        }
    }
}


