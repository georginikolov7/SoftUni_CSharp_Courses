﻿namespace P01_StudentSystem 
{
    public class Startup
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}