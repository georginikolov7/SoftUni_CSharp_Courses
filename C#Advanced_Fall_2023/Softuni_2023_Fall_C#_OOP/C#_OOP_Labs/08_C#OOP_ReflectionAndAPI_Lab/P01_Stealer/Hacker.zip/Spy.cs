﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace P01_Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string investigatedClassName, params string[] fieldsToInvestigate)
        {
            Type classType = Type.GetType(investigatedClassName);
            FieldInfo[] classFields = classType.GetFields((BindingFlags)60);

            Object classInstance = Activator.CreateInstance(classType, new object[] { });
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Class under investigation: {classType.FullName}");
            foreach (FieldInfo field in classFields.Where(f => fieldsToInvestigate.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }
            return sb.ToString().Trim();
        }
    }
}
