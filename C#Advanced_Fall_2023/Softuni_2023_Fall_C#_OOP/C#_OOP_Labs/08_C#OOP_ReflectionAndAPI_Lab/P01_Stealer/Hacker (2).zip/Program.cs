﻿

using P01_Stealer;
using System.Reflection;

namespace Stealer
{
    public class StartUp
    {
        static void Main()
        {
            Type type = typeof(Hacker);
            MethodInfo[] methods = type.GetMethods();
            foreach (MethodInfo method in methods)
            {
                Console.WriteLine(method.Name);
            }


            Spy spy = new();
            Console.WriteLine(spy.AnalyzeAccessModifiers("Stealer.Hacker"));
        }
    }
}