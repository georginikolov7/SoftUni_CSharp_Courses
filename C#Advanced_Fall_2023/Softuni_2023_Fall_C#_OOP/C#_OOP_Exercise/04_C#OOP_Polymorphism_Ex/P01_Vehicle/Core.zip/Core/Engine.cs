﻿using P01_Vehicle.Models;
using P01_Vehicle.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_Vehicle.Core
{
    public class Engine
    {
        private Dictionary<string, IVehicle> vehicles = new();
        public void Run()
        {
            string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            IVehicle vehicle = new Car(double.Parse(tokens[1]), double.Parse(tokens[2]));
            vehicles.Add("Car", vehicle);

            tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            vehicle = new Truck(double.Parse(tokens[1]), double.Parse(tokens[2]));
            vehicles.Add("Truck", vehicle);

            int countOfCommands = int.Parse(Console.ReadLine());
            for (int i = 0; i < countOfCommands; i++)
            {
                ProccessCommand();
            }

            foreach (var v in vehicles.Values)
            {
                Console.WriteLine(v);
            }

        }
        private void ProccessCommand()
        {
            string[] commandTokens = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string command = commandTokens[0];
            string vehicleType = commandTokens[1];
            double value = double.Parse(commandTokens[2]);
            if (command == "Drive")
            {
                Console.WriteLine(vehicles[vehicleType].Drive(value));
            }
            else
            {
                vehicles[vehicleType].Refuel(value);
            }
        }
    }
}
