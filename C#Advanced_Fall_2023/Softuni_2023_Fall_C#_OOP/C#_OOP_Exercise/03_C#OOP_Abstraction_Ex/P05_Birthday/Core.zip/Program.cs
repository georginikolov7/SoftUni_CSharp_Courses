﻿using P04_BorderControl.Core;

Engine engine = new Engine();
engine.Run();