﻿

using P05_GenericCountMethod;

List<Box<string>> boxes = new();
int n = int.Parse(Console.ReadLine());
for (int i = 0; i < n; i++)
{
    boxes.Add(new Box<string>(Console.ReadLine()));
}
string valueToCompare = Console.ReadLine();
int count = 0;
foreach (Box<string> box in boxes)
{
    if (valueToCompare.CompareTo(box.Value) < 0)
    {
        count++;
    }
}
Console.WriteLine(count);