﻿
using CustomComparator;
int[] array = Console.ReadLine()
    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
    .Select(int.Parse)
    .ToArray();
Array.Sort(array, new CustomComparer());
Console.WriteLine(string.Join( " ",array));