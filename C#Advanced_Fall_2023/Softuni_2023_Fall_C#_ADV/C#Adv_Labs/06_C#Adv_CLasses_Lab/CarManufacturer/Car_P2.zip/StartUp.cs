﻿namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            Car car = new Car();
            car.Make = "VW";
            car.Model = "Golf";
            car.Year = 2006;
            car.FuelQuantity = 1000;
            car.FuelConsumption = 10;
            car.Drive(10);
            Console.WriteLine(car.WhoAmI());
        }
    }
}
